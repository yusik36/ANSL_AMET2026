#!/usr/bin/env python3
"""Camera-driven corridor planner: one node from image to speed and steering.

Replaces the lane-following and obstacle-avoidance pair. Those split the job
into "follow the line" and "an obstacle has appeared, take over", which meant
control changed hands mid-corner and the lane node had to recover from
wherever avoidance left the car. Here an obstacle is just a place where the
drivable corridor is narrower, so there is no handover to get wrong.

Publishes:
  plan/speed      (Float64, m/s)   what the corridor allows right now
  plan/steering   (Float64, rad)   positive is left, matching Physicar
  plan/valid      (Bool)           false when there is nowhere to go, or the
                                   camera has gone quiet. judgment_node must
                                   fail safe on this, not average it away.

The planning itself lives in corridor.py with no ROS in it, so it can be --
and is -- checked against synthetic scenes and real frames without a
simulator running. This file is wiring: parameters, topics, staleness.

Parameters worth turning on race day, and nothing else:
  aggression        lateral acceleration budget, m/s^2. Not a measured
                    constant -- the knob. The simulator runs ODE's default
                    mu=1 on every wheel, worth about 9.8 m/s^2, which
                    flatters the real tyres, so the default here is
                    deliberately pessimistic.
  lookahead_gain    Ld = gain*v + base. ForzaETH's rule: as short as it can
                    be without the car weaving.
  lookahead_base
  max_range         how far the corridor is believed. Measured at 2.5 m in
                    the simulator; past 3 m the range error exceeds the
                    track's own half-width.
  road_h_min/max    the road's hue window. Everything outside it is an
                    obstacle, so this is the first thing to re-measure at the
                    venue -- its floor is not the simulator's grass and may
                    sit much closer to the track's own colour.
  paint_s_max       white edge paint: grey enough that hue means nothing, so
  paint_v_min       it is matched on being desaturated and bright.
  mark_h_min/max    the centre marking. The real track may not have one, or
  mark_s_min        may mark it differently; widen or disable accordingly.
  max_span          free spans wider than this are lost edges, not corridor.
                    Scales with track width, so it changes if the venue's
                    track is not 0.7-0.9 m across.
"""
import time

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import Bool, Float64
from cv_bridge import CvBridge, CvBridgeError

from physicar_planner import corridor as C

IMAGE_STALE_S = 0.4
PUBLISH_RATE_HZ = 20.0


class PlannerNode(Node):
    def __init__(self):
        super().__init__('planner_node')

        self.declare_parameter('aggression', 4.0)
        self.declare_parameter('lookahead_gain', 0.35)
        self.declare_parameter('lookahead_base', 0.70)
        self.declare_parameter('max_accel', C.MAX_ACCEL)
        self.declare_parameter('max_decel', C.MAX_DECEL)
        self.declare_parameter('min_range', C.DEFAULT_MIN_RANGE)
        self.declare_parameter('max_range', C.DEFAULT_MAX_RANGE)
        self.declare_parameter('samples', C.DEFAULT_SAMPLES)
        self.declare_parameter('max_lateral_slope', C.MAX_LATERAL_SLOPE)
        # Every colour bound is a parameter, not a constant. The venue will
        # not look like the simulator: its track is a different surface under
        # different light, there is no grass beside it but an exhibition-hall
        # floor, and the purple boundary wall does not exist at all. What has
        # to survive is the shape of the rule -- road is one cluster, the
        # paint on it is another, everything else is an obstacle -- while
        # every number in it gets re-measured on site.
        self.declare_parameter('road_h_min', C.ROAD_H_MIN)
        self.declare_parameter('road_h_max', C.ROAD_H_MAX)
        self.declare_parameter('paint_s_max', C.PAINT_S_MAX)
        self.declare_parameter('paint_v_min', C.PAINT_V_MIN)
        self.declare_parameter('mark_h_min', C.MARK_H_MIN)
        self.declare_parameter('mark_h_max', C.MARK_H_MAX)
        self.declare_parameter('mark_s_min', C.MARK_S_MIN)
        self.declare_parameter('max_span', C.MAX_PLAUSIBLE_SPAN)
        self.declare_parameter('speed_cap', C.MAX_SPEED)
        self.declare_parameter('debug', False)

        g = lambda n: self.get_parameter(n).value          # noqa: E731
        self.aggression = g('aggression')
        self.gain = g('lookahead_gain')
        self.base = g('lookahead_base')
        self.max_accel = g('max_accel')
        self.max_decel = g('max_decel')
        self.min_range = g('min_range')
        self.max_range = g('max_range')
        self.samples = int(g('samples'))
        self.max_slope = g('max_lateral_slope')
        self.road_h = (int(g('road_h_min')), int(g('road_h_max')))
        self.paint = (int(g('paint_s_max')), int(g('paint_v_min')))
        self.mark = (int(g('mark_h_min')), int(g('mark_h_max')),
                     int(g('mark_s_min')))
        self.max_span = g('max_span')
        self.speed_cap = g('speed_cap')
        self.debug = g('debug')

        self.bridge = CvBridge()
        self.speed_pub = self.create_publisher(Float64, 'plan/speed', 10)
        self.steer_pub = self.create_publisher(Float64, 'plan/steering', 10)
        self.valid_pub = self.create_publisher(Bool, 'plan/valid', 10)

        # Sensor QoS: the camera may publish best-effort, and a reliable
        # subscriber is DDS-incompatible with that -- it receives nothing and
        # says nothing about why.
        self.create_subscription(Image, 'image_raw', self.on_image,
                                 qos_profile_sensor_data)

        # speed is what is published; target_speed is what the corridor
        # allows. They are separate because the gap between them has to be
        # crossed at a bounded rate -- see on_tick.
        self.speed = 0.0
        self.target_speed = 0.0
        self.steering = 0.0
        self.valid = False
        self.last_image_time = 0.0
        self.last_tick = time.time()
        self.create_timer(1.0 / PUBLISH_RATE_HZ, self.on_tick)

        self.get_logger().info(
            'planner_node ready: aggression %.1f m/s^2, Ld = %.2f*v + %.2f, '
            'corridor %.2f-%.2f m, road hue %d-%d, spans over %.2f m ignored'
            % (self.aggression, self.gain, self.base, self.min_range,
               self.max_range, self.road_h[0], self.road_h[1], self.max_span))

    def on_image(self, msg: Image):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except CvBridgeError as e:
            self.get_logger().warn('cv_bridge failed, dropping frame: %s' % e)
            return
        self.last_image_time = time.time()

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        speed, steer, dbg = C.plan(
            hsv, self.speed, self.aggression, self.gain, self.base,
            min_range=self.min_range, max_range=self.max_range,
            samples=self.samples, max_slope=self.max_slope,
            max_span=self.max_span,
            block=(self.road_h, self.paint, self.mark))

        self.valid = dbg['target'] is not None
        # The corridor's verdict is a target, not a command: on_tick decides
        # how fast the car is allowed to approach it.
        self.target_speed = min(speed, self.speed_cap)
        self.steering = steer

        if self.debug:
            t = dbg['target']
            self.get_logger().info(
                'Ld %.2f  target %s  corner R %.2f  -> %.2f m/s %+.1f deg'
                % (dbg['lookahead'],
                   '(%.2f, %+.2f)' % t if t else 'none',
                   dbg.get('corner_radius', float('inf')),
                   self.speed, np.degrees(self.steering)))

    def on_tick(self):
        # Published on a timer rather than per frame so a dead camera shows
        # up as a stream of zeros, not as silence that something downstream
        # might read as "no news".
        now = time.time()
        dt = min(max(now - self.last_tick, 0.0), 0.2)
        self.last_tick = now

        fresh = (now - self.last_image_time) < IMAGE_STALE_S
        if not fresh:
            self.target_speed, self.steering, self.valid = 0.0, 0.0, False

        # Ramp rather than jump. Publishing the corridor's verdict directly
        # meant the first frame that saw a clear track commanded 2 m/s from a
        # standstill and the car was at the 3 m/s cap 200 ms later, still
        # turning out of the start box. Rate-limiting here rather than in
        # plan() keeps the ramp on the 20 Hz clock, so a camera that skips a
        # frame slows the car's response instead of jerking it.
        self.speed = C.ramp(self.target_speed, self.speed, dt,
                            self.max_accel, self.max_decel)
        self.speed_pub.publish(Float64(data=float(self.speed)))
        self.steer_pub.publish(Float64(data=float(self.steering)))
        self.valid_pub.publish(Bool(data=bool(self.valid)))


def main():
    rclpy.init()
    node = PlannerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.speed_pub.publish(Float64(data=0.0))
        except Exception:
            pass
        node.destroy_node()
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == '__main__':
    main()
